<?php

header('location: panel.php');
